---
name: Add a new theme
about: Use the following template if you want a new theme to be included in the collection.
title: Add <theme> to the collection.
labels: theme request
assignees: kovidgoyal

---

Please, include **theme** in the collection.

Below is a screenshot of the theme in kitty.
